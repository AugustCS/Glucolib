<?php
	require_once("index.php");
?>